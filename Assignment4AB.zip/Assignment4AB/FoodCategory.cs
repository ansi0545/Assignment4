﻿

namespace Assignment_AB
{
    enum FoodCategory
    {
        Meats,
        Pasta,
        Pizza,
        Fish,
        Seafood,
        Soups,
        Stew,
        Vegan,
        Vegetarian,
        Vegetarian_Dairy_Egg,
        Other
    }
}
